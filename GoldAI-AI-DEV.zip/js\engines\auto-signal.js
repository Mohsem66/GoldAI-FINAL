// =====================================================================
// GoldAI — Automatic Signal Monitor
// -----------------------------------------------------------------------
// Detects a NEWLY CLOSED candle (M5 for scalp, M15 for swing) and, only
// then, runs exactly one evaluation through the SAME pipeline as the
// manual "▶ شروع تحلیل AI" button (window.GoldAI.analyze() — not a
// parallel/duplicate analysis implementation).
//
// Hard rules enforced here:
//   - Never evaluates unless window.GoldAI_Data.dataMode === "live" AND
//     livePriceOk is true (real MT5 tick). Demo/offline data NEVER
//     produces an automatic signal.
//   - At most one evaluation per closed candle: dedup key is
//     symbol + timeframe + candle-close-timestamp.
//   - This module ONLY writes to the signal journal (localStorage). It
//     never calls /api/mt5/send-signal or any execution endpoint —
//     Signal detection and Trade execution stay fully separate.
//     AUTO_TRADING_ENABLED exists in config but is not wired to anything.
// =====================================================================

window.GoldAI_AutoSignal = (function () {
  const JOURNAL_KEY = "goldai_auto_signal_journal";
  const JOURNAL_CAP = 300;
  let timer = null;
  let lastCandleKey = null;
  let busy = false;

  function tfForMode(cfg) {
    return cfg.STRATEGY_MODE === "swing" ? "M15" : "M5";
  }

  function setStatus(text) {
    const el = document.getElementById("autoSignalStatus");
    if (el) el.textContent = text;
  }

  function readJournal() {
    try { return JSON.parse(localStorage.getItem(JOURNAL_KEY) || "[]"); } catch (_) { return []; }
  }
  function writeJournal(arr) {
    try { localStorage.setItem(JOURNAL_KEY, JSON.stringify(arr.slice(-JOURNAL_CAP))); } catch (_) {}
  }
  function logEntry(entry) {
    const j = readJournal();
    j.push(entry);
    writeJournal(j);
  }

  async function tick() {
    const cfg = window.GoldAI_Config || {};
    const data = window.GoldAI_Data;
    if (!cfg.AUTO_SIGNAL_ENABLED || busy) return;

    // Signal must come from valid LIVE MT5 data only — never demo/offline.
    if (!data || data.dataMode !== "live" || !data.livePriceOk) {
      setStatus("⏸ غیرفعال — قیمت زنده از MT5 در دسترس نیست (Signal Trading = Disabled)");
      return;
    }

    const tf = tfForMode(cfg);
    const symbol = cfg.SYMBOL || "XAUUSD.";
    let res;
    try {
      res = await data.fetchMT5History(tf, 2); // cheap peek — just the latest closed bar(s)
    } catch (e) {
      setStatus("خطا در بررسی کندل جدید: " + e.message);
      return;
    }
    if (!res || res.status !== "ok" || !res.candles || !res.candles.length) {
      setStatus("⏸ کندل واقعی MT5 در دسترس نیست (" + tf + ")");
      return;
    }

    const lastClosed = res.candles[res.candles.length - 1]; // bridge already excludes the still-forming bar
    const key = symbol + "|" + tf + "|" + lastClosed.time;
    if (key === lastCandleKey) {
      setStatus("👁 در حال پایش — منتظر بسته‌شدن کندل بعدی " + tf);
      return; // same candle already evaluated — never duplicate a signal for it
    }

    busy = true;
    lastCandleKey = key;
    setStatus("⏳ کندل جدید " + tf + " بسته شد — در حال ارزیابی...");
    try {
      await window.GoldAI.analyze(); // exact same Decision Pipeline as the manual button
      const result = window.GoldAI_V1_Result;
      if (result) {
        logEntry({
          source: "auto",
          candleKey: key,
          symbol, timeframe: tf,
          timestamp: result.timestamp,
          signal: result.signal,
          confidence: result.confidence,
          entry: result.entry,
          stopLoss: result.stopLoss,
          tp1: result.tp1, tp2: result.tp2, tp3: result.tp3,
          reason: result.reason,
          warnings: result.warnings,
          executionEligible: false // Auto Trading is not wired — journal-only in this build
        });
      }
      setStatus("✅ آخرین ارزیابی: " + new Date().toLocaleTimeString("fa-IR") + " (کندل " + tf + " بسته‌شده)");
    } catch (e) {
      setStatus("خطا در تحلیل خودکار: " + e.message);
    } finally {
      busy = false;
    }
  }

  function start() {
    const cfg = window.GoldAI_Config || {};
    cfg.AUTO_SIGNAL_ENABLED = true;
    if (timer) clearInterval(timer);
    tick();
    timer = setInterval(tick, cfg.AUTO_SIGNAL_POLL_MS || 15000);
  }

  function stop() {
    const cfg = window.GoldAI_Config || {};
    cfg.AUTO_SIGNAL_ENABLED = false;
    if (timer) { clearInterval(timer); timer = null; }
    setStatus("خاموش");
  }

  function toggle(on) { if (on) start(); else stop(); }

  function showJournal() {
    const wrap = document.getElementById("autoSignalJournalWrap");
    const table = document.getElementById("autoSignalJournalTable");
    if (!wrap || !table) return;
    const rows = readJournal().slice(-100).reverse();
    const head = "<tr>" + ["Time", "TF", "Signal", "Conf", "Entry", "SL", "TP1", "Reason"]
      .map(h => "<th style='padding:4px 6px;border-bottom:1px solid #2a2a35;text-align:left'>" + h + "</th>").join("") + "</tr>";
    const body = rows.map(r => {
      const td = v => "<td style='padding:3px 6px;border-bottom:1px solid #1c1c26'>" + (v == null ? "—" : v) + "</td>";
      const t = r.timestamp ? new Date(r.timestamp).toLocaleString("fa-IR") : "—";
      return "<tr>" + td(t) + td(r.timeframe) + td(r.signal) + td(r.confidence) + td(r.entry) + td(r.stopLoss) + td(r.tp1) + td((r.reason || "").slice(0, 60)) + "</tr>";
    }).join("");
    table.innerHTML = head + body;
    wrap.classList.toggle("hidden");
  }

  function clearJournal() {
    writeJournal([]);
    const table = document.getElementById("autoSignalJournalTable");
    if (table) table.innerHTML = "";
  }

  function getJournal() { return readJournal(); }

  return { start, stop, toggle, tick, showJournal, clearJournal, getJournal };
})();
